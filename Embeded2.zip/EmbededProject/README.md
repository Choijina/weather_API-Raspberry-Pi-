# 라즈베리 파이3 관련 에러


## 라즈베리 파이 키보드 입력 불가능 
> putty의 category : SSH > Serial > Flow control=None으로 세팅

## 라즈베리 파이 버전
- 라즈베리파이 디바이스 : RASPBERRY PI 3
- 운영체제 : RASPBERRY PI OS(64-BIT)
