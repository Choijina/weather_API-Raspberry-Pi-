from flask import Flask
from .main_views import bp as main_bp

def create_app():
    app = Flask(__name__)

    #@app.route('/')
    #def hello_pybo():
    #    return 'Hello, Pybo'
    app.register_blueprint(main_bp)
    


    return app

