import os

class Config:
    SERVICE_KEY = os.environ.get('SERVICE_KEY') or 'YOUR_DEFAULT_SERVICE_KEY'
